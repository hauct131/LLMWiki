---
title: "Charge-Coupled Device (CCD"
tags: [concept, stub]
status: stub
---

## Definition

A Charge-Coupled Device (CCD) is an electronic light sensor used to capture optical elements. It converts light into electrical charges and processes these signals for image formation or data storage, operating similarly to a bucket brigade of electrons that are shifted across the chip from one capacitor node to another until they can be read at the output contact pins.

## Why It Matters

CCDs have been fundamental in advancing digital imaging technology due to their high sensitivity and image quality, making them essential for applications ranging from photography to astronomy.

## Variants / Related Terms

Back-Illuminated CCD (BIC), PCO CCD (Photonics Microchannel Arrays)

---
*Auto-generated concept stub — verify before publishing.*
