---
title: "Attention Mechanisms (Self, Cross"
tags: [concept, stub]
status: stub
---

## Definition

Attention Mechanisms are computational processes that allow neural networks to focus on different parts of input data selectively when processing it for tasks such as translation or image recognition. In self-attention (intra-attention), the model attends to various positions within a single sequence, while cross-attention involves focusing across two separate sequences simultaneously.

## Why It Matters

Attention Mechanisms significantly improve neural network performance by enabling dynamic weighting of input features relevant for specific tasks.

## Variants / Related Terms

Self-Attention, Cross-Attention (or NONE - in some contexts where attention is not applicable)

---
*Auto-generated concept stub — verify before publishing.*
