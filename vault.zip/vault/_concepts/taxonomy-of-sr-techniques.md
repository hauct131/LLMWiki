---
title: "Taxonomy of SR techniques"
tags: [concept, stub]
status: stub
---

## Definition

Taxonomy of SR techniques refers to the classification and categorization of various methods used in super-resolution imaging or processing, particularly those employing deep convolutional neural networks (DCNNs). These categories are often based on factors such as network architecture complexity, training data requirements, computational efficiency, and application specificity.

## Why It Matters

Understanding the taxonomy of SR techniques is crucial for selecting appropriate methods to enhance image resolution in different applications ranging from medical imaging to satellite photography.

## Variants / Related Terms

Deep Convolutional Neural Networks (DCNN), Generative Adversarial Networks (GAN) based super-resolution, Non-Local Super Resolution Techniques, Multi-Frame Super Resolution Methods

---
*Auto-generated concept stub — verify before publishing.*
