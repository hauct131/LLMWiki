---
title: "Generative Adversarial Networks"
tags: [concept, stub]
status: stub
---

## Definition

Generative Adversarial Networks (GANs) are a class of artificial intelligence algorithms used in unsupervised machine learning that involve two neural networks, namely the generator and discriminator, competing against each other to generate new data samples indistinguishable from real ones. The generator creates synthetic images or sequences, while the discriminator evaluates them alongside authentic examples, with both aiming to outperform in their respective roles through iterative training cycles.

## Why It Matters

GAN-based models have significantly impacted the field of computer vision by providing state-of-the-art solutions for tasks such as image super-resolution, style transferring and photo editing without relying on extensive labeled datasets—a substantial advancement over traditional methods that often require manual labeling or fixed algorithms.

## Variants / Related Terms

Wasserstein GAN (WGAN), Progressive Growing of GANs

---
*Auto-generated concept stub — verify before publishing.*
