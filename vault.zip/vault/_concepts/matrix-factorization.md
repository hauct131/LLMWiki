---
title: "Matrix Factorization"
tags: [concept, stub]
status: stub
---

## Definition

Matrix Factorization is a class of collaborative filtering algorithms used for making predictions about user preferences. It works by decomposing a large matrix into products of smaller matrices to discover latent factors that explain observed data points in terms of these underlying structures. Typically, this involves splitting the original user-item interaction matrix into lower dimensional representations corresponding to users and items as vectors within a shared factor space.

## Why It Matters

Matrix Factorization is crucial for building recommender systems by predicting unknown preferences or ratings based on existing patterns in data.

## Variants / Related Terms

Singular Value Decomposition (SVD), Non-negative Matrix Factorization (NMF)

---
*Auto-generated concept stub — verify before publishing.*
