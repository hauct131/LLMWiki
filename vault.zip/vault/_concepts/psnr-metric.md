---
title: "PSNR Metric"
tags: [concept, stub]
status: stub
---

## Definition

PSNR Metric, or Peak Signal-tofaloss Ratio, is an objective measure that quantifies the quality of a reconstructed image compared to its original version. It calculates the ratio between the maximum possible power of a signal (in this case, pixel intensity) and the power of corrupting noise that affects the fidelity of its representation or replication.

## Why It Matters

PSNR is widely used as an indicator to evaluate the performance of image compression algorithms and super-resolution methods by assessing how much information loss occurs during these processes.

## Variants / Related Terms

Structural Similarity Index (SSIM), Multi-Scale SSIM, VIF (Visual Information Fidelity)

---
*Auto-generated concept stub — verify before publishing.*
